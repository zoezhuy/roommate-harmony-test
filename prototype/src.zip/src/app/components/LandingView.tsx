import { Home, Users } from 'lucide-react';

interface LandingViewProps {
  onStart: () => void;
}

const animalEmojis = ['🐱', '🐶', '🐼', '🦊', '🦉', '🐬', '🐿️', '🐢'];

export function LandingView({ onStart }: LandingViewProps) {
  return (
    <div className="animate-fade-in">
      <header className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-extrabold mb-2 tracking-tight" style={{ color: '#FF7043' }}>
          <Home className="inline-block mr-2 mb-1" size={40} />
          Harmony Test
        </h1>
        <p className="text-gray-500 font-semibold text-lg">发现你的室友灵魂动物与契合度评分。</p>
      </header>

      <div className="glass-panel rounded-3xl p-8 md:p-12 text-center">
        <div className="flex justify-between items-center w-full mb-8 overflow-hidden px-1 sm:px-4">
          {animalEmojis.map((emoji, index) => (
            <span
              key={index}
              className="emoji-avatar"
              style={{
                animation: 'bounce 3s infinite',
                animationDelay: `${index * 0.1}s`
              }}
            >
              {emoji}
            </span>
          ))}
        </div>
        
        <h2 className="text-2xl font-bold mb-4" style={{ color: '#455A64' }}>
          探索你的居住风格
        </h2>
        <p className="text-gray-600 mb-8 leading-relaxed">
          通过这 20 道测试题来分析你们的契合度。 
          请诚实回答关于睡眠习惯、整洁卫生和社交边界的问题。 
          <br /><br />
          <span className="px-2 py-1 rounded text-sm font-bold border inline-flex items-center gap-2" style={{ backgroundColor: '#FFFDE7', color: '#F57F17', borderColor: '#FFF59D' }}>
            <Users size={16} />
            双人依次测试
          </span>
        </p>

        <div className="space-y-4">
          <button 
            onClick={onStart}
            className="w-full text-white font-bold py-4 px-8 rounded-2xl shadow-lg transform transition hover:-translate-y-1 active:scale-95 text-lg"
            style={{ backgroundColor: '#FF7043' }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F4511E'}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF7043'}
          >
            开始新测试
          </button>
          <p className="text-xs text-gray-400 mt-4">每人大约需要 3 分钟</p>
        </div>
      </div>
    </div>
  );
}
