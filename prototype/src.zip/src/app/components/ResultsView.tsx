import { useEffect, useState } from 'react';
import { HeartCrack, Sparkles, Lightbulb } from 'lucide-react';
import type { Animal } from '@/app/data/quiz-data';

interface ResultsViewProps {
  score: number;
  p1Animal: Animal;
  p2Animal: Animal;
  analysis: {
    conflictText: string;
    habitText: string;
    tipText: string;
  };
  onRestart: () => void;
}

export function ResultsView({ score, p1Animal, p2Animal, analysis, onRestart }: ResultsViewProps) {
  const [displayScore, setDisplayScore] = useState(0);
  const [circleOffset, setCircleOffset] = useState(540);

  useEffect(() => {
    // Animate score circle
    const circumference = 540;
    const offset = circumference - ((score / 100) * circumference);
    
    setTimeout(() => {
      setCircleOffset(offset);
    }, 500);

    // Animate score number
    if (score === 0) {
      setDisplayScore(0);
    } else {
      let current = 0;
      const interval = setInterval(() => {
        if (current >= score || current > 100) {
          clearInterval(interval);
          setDisplayScore(score);
        } else {
          setDisplayScore(current);
          current++;
        }
      }, 20);

      return () => clearInterval(interval);
    }
  }, [score]);

  const getScoreLabel = () => {
    if (score > 80) return { text: '天作之合！', color: '#10B981' };
    if (score > 50) return { text: '可靠的室友', color: '#3B82F6' };
    return { text: '仍需磨合', color: '#F97316' };
  };

  const scoreLabel = getScoreLabel();

  return (
    <div className="animate-fade-in pb-20">
      {/* Overall Score Card */}
      <div className="glass-panel rounded-3xl p-8 mb-6 text-center relative overflow-hidden">
        <div 
          className="absolute top-0 left-0 w-full h-2"
          style={{
            background: 'linear-gradient(to right, #FCE4EC, #F3E5F5, #E3F2FD)'
          }}
        />
        
        <h2 className="text-xl font-bold text-gray-500 mb-4 uppercase tracking-widest">
          和谐度得分
        </h2>
        
        <div className="relative inline-flex items-center justify-center">
          <svg className="w-48 h-48">
            <circle 
              className="text-gray-100" 
              strokeWidth="12" 
              stroke="currentColor" 
              fill="transparent" 
              r="86" 
              cx="96" 
              cy="96" 
            />
            <circle 
              className="text-[#26A69A]" 
              strokeWidth="12" 
              strokeDasharray="540" 
              strokeDashoffset={circleOffset}
              strokeLinecap="round" 
              stroke="currentColor" 
              fill="transparent" 
              r="86" 
              cx="96" 
              cy="96" 
              style={{
                transition: 'stroke-dashoffset 2s ease-out',
                transform: 'rotate(-90deg)',
                transformOrigin: '50% 50%'
              }}
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-6xl font-extrabold" style={{ color: '#455A64' }}>
              {displayScore}%
            </span>
            <span className="text-sm font-bold" style={{ color: scoreLabel.color }}>
              {scoreLabel.text}
            </span>
          </div>
        </div>
      </div>

      {/* Animal Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Player 1 */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col items-center text-center">
          <span className="text-xs font-bold bg-gray-100 text-gray-500 px-2 py-1 rounded mb-2">
            玩家 1
          </span>
          <span 
            className="text-6xl mb-2"
            style={{ animation: 'bounce 3s infinite' }}
          >
            {p1Animal.emoji}
          </span>
          <h3 className="text-xl font-bold mb-1" style={{ color: '#455A64' }}>
            {p1Animal.name}
          </h3>
          <p className="text-sm text-gray-500 leading-tight">
            {p1Animal.desc}
          </p>
        </div>
        
        {/* Player 2 */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col items-center text-center">
          <span className="text-xs font-bold bg-gray-100 text-gray-500 px-2 py-1 rounded mb-2">
            玩家 2
          </span>
          <span 
            className="text-6xl mb-2"
            style={{ 
              animation: 'bounce 3s infinite',
              animationDelay: '1s'
            }}
          >
            {p2Animal.emoji}
          </span>
          <h3 className="text-xl font-bold mb-1" style={{ color: '#455A64' }}>
            {p2Animal.name}
          </h3>
          <p className="text-sm text-gray-500 leading-tight">
            {p2Animal.desc}
          </p>
        </div>
      </div>

      {/* Analysis Accordion */}
      <div className="space-y-4">
        <div className="glass-panel rounded-2xl p-6">
          <h3 className="text-lg font-bold mb-3 flex items-center" style={{ color: '#455A64' }}>
            <HeartCrack className="mr-2" size={20} style={{ color: '#FFCCBC' }} />
            冲突处理风格
          </h3>
          <p className="text-gray-600 text-sm">{analysis.conflictText}</p>
        </div>

        <div className="glass-panel rounded-2xl p-6">
          <h3 className="text-lg font-bold mb-3 flex items-center" style={{ color: '#455A64' }}>
            <Sparkles className="mr-2" size={20} style={{ color: '#26A69A' }} />
            卫生与生活习惯
          </h3>
          <p className="text-gray-600 text-sm">{analysis.habitText}</p>
        </div>

        <div className="glass-panel rounded-2xl p-6 border-l-4" style={{ borderColor: '#FF7043' }}>
          <h3 className="text-lg font-bold mb-3 flex items-center" style={{ color: '#455A64' }}>
            <Lightbulb className="mr-2" size={20} style={{ color: '#FDD835' }} />
            给你们的核心建议
          </h3>
          <p className="text-gray-600 text-sm font-medium italic">{analysis.tipText}</p>
        </div>
      </div>

      <button 
        onClick={onRestart}
        className="w-full mt-8 bg-gray-800 hover:bg-black text-white font-bold py-4 px-8 rounded-2xl shadow-lg transition"
      >
        重新开始
      </button>
    </div>
  );
}
