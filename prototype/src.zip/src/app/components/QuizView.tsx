import { useState } from 'react';
import { questions } from '@/app/data/quiz-data';

interface QuizViewProps {
  currentPlayer: 1 | 2;
  currentQuestionIndex: number;
  onAnswer: (value: number) => void;
}

export function QuizView({ currentPlayer, currentQuestionIndex, onAnswer }: QuizViewProps) {
  const [selectedValue, setSelectedValue] = useState<number | null>(null);
  const question = questions[currentQuestionIndex];
  const progress = (currentQuestionIndex / questions.length) * 100;

  const handleAnswer = (value: number) => {
    setSelectedValue(value);
    setTimeout(() => {
      onAnswer(value);
      setSelectedValue(null);
    }, 250);
  };

  return (
    <div className="glass-panel rounded-3xl p-6 md:p-10 animate-fade-in relative overflow-hidden">
      {/* Progress Bar */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gray-100">
        <div 
          className="h-full transition-all duration-300"
          style={{ 
            width: `${progress}%`,
            backgroundColor: '#26A69A'
          }}
        />
      </div>

      <div className="flex justify-between items-center mb-6 mt-2">
        <span 
          className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider"
          style={{
            backgroundColor: currentPlayer === 1 ? '#E3F2FD' : '#FCE4EC',
            color: currentPlayer === 1 ? '#1565C0' : '#C2185B'
          }}
        >
          玩家 {currentPlayer}
        </span>
        <span className="text-gray-400 text-sm font-mono">
          {currentQuestionIndex + 1}/{questions.length}
        </span>
      </div>

      {/* Question Card */}
      <div className="mb-8 min-h-[120px] flex flex-col justify-center">
        <h2 className="text-xs font-bold uppercase mb-2 tracking-widest" style={{ color: '#FF7043' }}>
          {question.cat}
        </h2>
        <h3 className="text-xl md:text-2xl font-bold text-gray-800 leading-snug">
          {question.text}
        </h3>
      </div>

      {/* Likert Scale */}
      <div className="grid grid-cols-5 gap-2 md:gap-4 mb-8">
        {[1, 2, 3, 4, 5].map((value) => (
          <div key={value} className="flex flex-col items-center gap-2">
            <button
              onClick={() => handleAnswer(value)}
              className={`likert-btn w-10 h-10 md:w-14 md:h-14 rounded-xl border-2 flex items-center justify-center text-lg font-bold transition bg-white ${
                selectedValue === value ? 'selected' : 'border-gray-200 text-gray-400 hover:text-[#26A69A] hover:border-[#26A69A]'
              }`}
            >
              {value}
            </button>
            {value === 1 && (
              <span className="text-[10px] text-gray-400 text-center leading-tight">绝不 / 否</span>
            )}
            {value === 3 && (
              <span className="text-[10px] text-gray-400 text-center leading-tight">中立</span>
            )}
            {value === 5 && (
              <span className="text-[10px] text-gray-400 text-center leading-tight">总是 / 是</span>
            )}
          </div>
        ))}
      </div>

      <div className="text-center text-gray-300 text-sm">
        选择一个选项以自动进行
      </div>
    </div>
  );
}
