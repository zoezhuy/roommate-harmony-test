import { Sparkles } from 'lucide-react';

interface IntermissionViewProps {
  onContinue: () => void;
}

export function IntermissionView({ onContinue }: IntermissionViewProps) {
  return (
    <div className="glass-panel rounded-3xl p-8 md:p-12 text-center animate-fade-in">
      <div className="mb-6">
        <Sparkles className="mx-auto" size={64} style={{ color: '#FFD700' }} />
      </div>
      <h2 className="text-2xl font-bold mb-4" style={{ color: '#455A64' }}>
        玩家 1 已完成！
      </h2>
      <p className="text-gray-600 mb-8">
        请将设备交给你的准室友（玩家 2），他们将回答相同的问题。
      </p>
      <button 
        onClick={onContinue}
        className="text-white font-bold py-3 px-8 rounded-2xl shadow-lg transform transition hover:-translate-y-1"
        style={{ backgroundColor: '#26A69A' }}
        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#00897B'}
        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#26A69A'}
      >
        我是玩家 2 - 开始测试
      </button>
    </div>
  );
}
