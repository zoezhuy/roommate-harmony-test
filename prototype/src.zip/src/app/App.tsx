import { useState } from 'react';
import { LandingView } from '@/app/components/LandingView';
import { QuizView } from '@/app/components/QuizView';
import { IntermissionView } from '@/app/components/IntermissionView';
import { ResultsView } from '@/app/components/ResultsView';
import { determineAnimal, calculateCompatibility, generateAnalysis } from '@/app/utils/quiz-logic';
import { questions } from '@/app/data/quiz-data';

type View = 'landing' | 'quiz' | 'intermission' | 'results';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [currentPlayer, setCurrentPlayer] = useState<1 | 2>(1);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [p1Answers, setP1Answers] = useState<number[]>([]);
  const [p2Answers, setP2Answers] = useState<number[]>([]);

  const startQuiz = () => {
    setCurrentView('quiz');
    setCurrentPlayer(1);
    setCurrentQuestionIndex(0);
    setP1Answers([]);
    setP2Answers([]);
  };

  const handleAnswer = (value: number) => {
    if (currentPlayer === 1) {
      const newAnswers = [...p1Answers, value];
      setP1Answers(newAnswers);
      
      if (newAnswers.length < questions.length) {
        setCurrentQuestionIndex(newAnswers.length);
      } else {
        setCurrentView('intermission');
      }
    } else {
      const newAnswers = [...p2Answers, value];
      setP2Answers(newAnswers);
      
      if (newAnswers.length < questions.length) {
        setCurrentQuestionIndex(newAnswers.length);
      } else {
        setCurrentView('results');
      }
    }
  };

  const startPlayerTwo = () => {
    setCurrentPlayer(2);
    setCurrentQuestionIndex(0);
    setCurrentView('quiz');
  };

  const restart = () => {
    setCurrentView('landing');
    setCurrentPlayer(1);
    setCurrentQuestionIndex(0);
    setP1Answers([]);
    setP2Answers([]);
  };

  // Calculate results
  const score = currentView === 'results' ? calculateCompatibility(p1Answers, p2Answers) : 0;
  const p1Animal = currentView === 'results' ? determineAnimal(p1Answers) : null;
  const p2Animal = currentView === 'results' ? determineAnimal(p2Answers) : null;
  const analysis = currentView === 'results' ? generateAnalysis(p1Answers, p2Answers) : null;

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-4"
      style={{ 
        color: '#455A64',
        backgroundColor: '#FAFAFA',
        backgroundImage: 'radial-gradient(#E0F2F1 2px, transparent 2px), radial-gradient(#FCE4EC 2px, transparent 2px)',
        backgroundSize: '30px 30px',
        backgroundPosition: '0 0, 15px 15px'
      }}
    >
      <div className="w-full max-w-2xl mx-auto relative">
        {currentView === 'landing' && <LandingView onStart={startQuiz} />}
        
        {currentView === 'quiz' && (
          <QuizView
            currentPlayer={currentPlayer}
            currentQuestionIndex={currentQuestionIndex}
            onAnswer={handleAnswer}
          />
        )}
        
        {currentView === 'intermission' && (
          <IntermissionView onContinue={startPlayerTwo} />
        )}
        
        {currentView === 'results' && p1Animal && p2Animal && analysis && (
          <ResultsView
            score={score}
            p1Animal={p1Animal}
            p2Animal={p2Animal}
            analysis={analysis}
            onRestart={restart}
          />
        )}
      </div>
    </div>
  );
}
