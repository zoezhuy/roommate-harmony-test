import { animals, questions } from '@/app/data/quiz-data';
import type { Animal } from '@/app/data/quiz-data';

export function determineAnimal(answers: number[]): Animal {
  const socialIndices = [8, 9, 10, 11, 29, 31];
  const orderIndices = [4, 5, 6, 7, 36, 39];
  const energyIndices = [0, 1, 2, 3, 12, 13];

  const getAvg = (indices: number[]): number => {
    let sum = 0;
    let count = 0;
    indices.forEach(i => {
      if (answers[i] !== undefined) {
        sum += answers[i];
        count++;
      }
    });
    return count === 0 ? 0 : sum / count;
  };

  const socialScore = getAvg(socialIndices);
  const orderScore = getAvg(orderIndices);
  const energyScore = getAvg(energyIndices);

  if (socialScore > 3.5 && orderScore < 3) return animals.DOG;
  if (socialScore < 3 && orderScore > 3.5) return animals.CAT;
  if (energyScore > 3.5 && socialScore < 3) return animals.OWL;
  if (socialScore > 3.5 && energyScore > 3.5) return animals.DOLPHIN;
  if (orderScore > 4) return animals.SQUIRREL;
  if (socialScore < 2.5 && energyScore < 3) return animals.TURTLE;
  if (orderScore < 2.5 && energyScore < 3) return animals.PANDA;
  
  return animals.FOX;
}

export function calculateCompatibility(p1Answers: number[], p2Answers: number[]): number {
  let totalDiff = 0;
  const maxDiffPossible = questions.length * 4;

  questions.forEach((_, index) => {
    const ans1 = p1Answers[index];
    const ans2 = p2Answers[index];
    
    if (ans1 !== undefined && ans2 !== undefined) {
      totalDiff += Math.abs(ans1 - ans2);
    }
  });

  const percent = 100 - ((totalDiff / maxDiffPossible) * 100);
  const result = Math.round(percent);
  
  return isNaN(result) ? 0 : result;
}

interface Analysis {
  conflictText: string;
  habitText: string;
  tipText: string;
}

export function generateAnalysis(p1Answers: number[], p2Answers: number[]): Analysis {
  const getCatAvg = (catName: string, answers: number[]): number => {
    const catQs = questions.filter(q => q.cat === catName);
    if (catQs.length === 0) return 0;
    let sum = 0;
    let validCount = 0;
    catQs.forEach(q => {
      const idx = questions.findIndex(item => item.id === q.id);
      if (answers[idx] !== undefined) {
        sum += answers[idx];
        validCount++;
      }
    });
    return validCount === 0 ? 0 : sum / validCount;
  };

  const p1Conflict = getCatAvg('冲突', p1Answers);
  const p2Conflict = getCatAvg('冲突', p2Answers);
  const p1Clean = getCatAvg('整洁度', p1Answers);
  const p2Clean = getCatAvg('整洁度', p2Answers);

  let conflictText = "";
  let habitText = "";
  let tipText = "";

  if (Math.abs(p1Conflict - p2Conflict) > 2) {
    conflictText = "你们处理冲突的方式大不相同。一个人倾向于立即解决，而另一个人可能需要时间或选择回避。建议建立一条规则：“在讨论激烈问题前先等待 24 小时，但必须在之后进行沟通。”";
  } else if (p1Conflict < 2.5 && p2Conflict < 2.5) {
    conflictText = "你们都倾向于回避冲突，这可能会导致消极对抗。尝试安排每月的“寝室会议”，在小问题变成大麻烦之前将其公开讨论。";
  } else {
    conflictText = "你们的冲突处理风格相对一致。你们可能都看重直率或都看重和谐。请继续保持开放的沟通。";
  }

  if (Math.abs(p1Clean - p2Clean) > 1.5) {
    habitText = "“整洁度差距”是你们最大的障碍。较爱干净的那个人不应该只是默默地替另一个人收拾——那样会积累怨气。建议制定一份严格的家务清单。";
  } else {
    habitText = "你们对整洁的标准非常相似。这是一个巨大的优势！只需确保你们在浴室和厨房的“干净”标准上达成共识即可。";
  }

  const compatibility = calculateCompatibility(p1Answers, p2Answers);
  if (compatibility > 80) {
    tipText = "你们简直是天作之合！祝你们相处愉快，但也别太封闭，记得继续结交新朋友。";
  } else if (compatibility > 50) {
    tipText = "你们是一对可以磨合的伙伴。重点关注“三大核心”：客人、噪音和洗碗。如果能在这些方面达成一致，其他都不是问题。";
  } else {
    tipText = "异性相吸，但也会互相困扰。请立即拟定一份“室友协议”，涵盖睡眠时间和客人到访规定。明确的边界将拯救这段友谊。";
  }

  return { conflictText, habitText, tipText };
}
