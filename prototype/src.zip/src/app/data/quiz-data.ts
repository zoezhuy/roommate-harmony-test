export interface Animal {
  emoji: string;
  name: string;
  desc: string;
  type: string;
}

export interface Question {
  id: number;
  cat: string;
  text: string;
}

export const animals: Record<string, Animal> = {
  CAT: { 
    emoji: '🐱', 
    name: '猫咪', 
    desc: '独立、爱干净、注重隐私。需要安静的时间来充电。', 
    type: 'introvert-tidy' 
  },
  DOG: { 
    emoji: '🐶', 
    name: '狗狗', 
    desc: '社交达人、不拘小节、忠诚。喜欢带客人回家，但可能会忘记洗碗。', 
    type: 'extrovert-messy' 
  },
  PANDA: { 
    emoji: '🐼', 
    name: '熊猫', 
    desc: '随和、包容、爱睡觉。不惜一切代价避免冲突。', 
    type: 'lazy-chill' 
  },
  FOX: { 
    emoji: '🦊', 
    name: '狐狸', 
    desc: '聪明、适应力强、生活平衡。擅长协商寝室规则。', 
    type: 'balanced' 
  },
  OWL: { 
    emoji: '🦉', 
    name: '猫头鹰', 
    desc: '夜行动物。在别人睡觉时最活跃。需要对噪音的容忍度。', 
    type: 'night-owl' 
  },
  DOLPHIN: { 
    emoji: '🐬', 
    name: '海豚', 
    desc: '活泼、精力充沛、爱交流。需要一个充满活力的家。', 
    type: 'active-social' 
  },
  SQUIRREL: { 
    emoji: '🐿️', 
    name: '松鼠', 
    desc: '总是很忙、有条理，对凌乱感到有些焦虑。', 
    type: 'anxious-tidy' 
  },
  TURTLE: { 
    emoji: '🐢', 
    name: '乌龟', 
    desc: '步调缓慢、避免冲突，喜欢待在自己的“壳”（房间）里。', 
    type: 'shy-quiet' 
  }
};

export const questions: Question[] = [
  // Sleep
  { id: 1, cat: '睡眠', text: '我倾向于在午夜前上床睡觉。' },
  { id: 2, cat: '睡眠', text: '我在深夜时的效率很高。' },
  { id: 3, cat: '睡眠', text: '我需要绝对的安静才能入睡。' },
  
  // Cleanliness
  { id: 4, cat: '整洁度', text: '吃完饭后我会立即洗碗。' },
  { id: 5, cat: '整洁度', text: '如果室友把衣服放在公共家具上，会让我感到困扰。' },
  { id: 6, cat: '整洁度', text: '我会严格遵守打扫计划。' },
  
  // Social
  { id: 7, cat: '社交', text: '我喜欢邀请朋友来我们的房间/公寓聚会。' },
  { id: 8, cat: '社交', text: '我每天都需要几个小时的独处时间。' },
  { id: 9, cat: '社交', text: '我希望我的室友能成为我最好的朋友。' },
  
  // Noise
  { id: 10, cat: '噪音', text: '我经常不戴耳机听音乐。' },
  { id: 11, cat: '噪音', text: '当我想专注时，电视开着会让我分心。' },
  
  // Sharing & Privacy
  { id: 12, cat: '共享', text: '我会大方地分享食物和杂货。' },
  { id: 13, cat: '共享', text: '我希望客人在到访前能先发短信告知。' },
  { id: 14, cat: '共享', text: '我的卧室门通常是关着的。' },

  // Conflict Style
  { id: 15, cat: '冲突', text: '当问题发生时，我会立即提出。' },
  { id: 16, cat: '冲突', text: '我愿意在房间温度上做出妥协。' },

  // Habits
  { id: 17, cat: '习惯', text: '我经常做复杂的饭菜。' },
  { id: 18, cat: '习惯', text: '我有很多个人物品/杂物。' },

  // Boundaries
  { id: 19, cat: '边界', text: '留宿客人随时都可以。' },
  { id: 20, cat: '边界', text: '我会按时缴纳账单/租金。' }
];
